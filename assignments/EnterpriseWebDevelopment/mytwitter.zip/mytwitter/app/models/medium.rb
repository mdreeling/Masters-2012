class Medium < ActiveRecord::Base
  has_many :movie_reviews
end
