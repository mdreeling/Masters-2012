Enterprise Component Development 

Assignment 2 - April 20th 2012

New Services
============
Add Match Result Service
Add Product Service (For Licensing)
Add Licensing Deal (For Players)

New Domain Objects
==================
Result
LicensingDeal
Product 

Unit Tests
==========
addResult Spring Unit Test
addLicensingDeal Spring Unit Test
addProduct Spring Unit Test