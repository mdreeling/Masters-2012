Enterprise Component Development 

Assignment 1 - Feb 24th 2012

Run MainApp as a JUnit to test.