package doconnor.aop.dao;

public class HibetnateDAO {
 
	public HibetnateDAO() {
		super();
	}

}