package doconnor.jpa.view.commands;

public interface Command {
	public void execute() ;
	public String help() ;
}
