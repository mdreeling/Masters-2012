
cp ../site/public/index.html assets/www
cp ../site/public/js/*.js assets/www/js
cp ../site/public/img/*.png assets/www/img

cp ../site/public/css/*.css assets/www/css
cp ../site/public/css/images/*.png assets/www/css/images

cp ../site/public/css/android/style.css assets/www/css/style.css


