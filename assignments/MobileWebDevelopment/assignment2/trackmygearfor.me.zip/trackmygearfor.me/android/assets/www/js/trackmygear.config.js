var initialscreen = "list"
var modelurl = "http://trackmygearfor.me/api/rest/inventory"
var twitterauthurl = "http://trackmygearfor.me/auth/twitter"
var sendmailurl = 'http://www.trackmygearfor.me/sendmail/tmg@dreeling.com/'
