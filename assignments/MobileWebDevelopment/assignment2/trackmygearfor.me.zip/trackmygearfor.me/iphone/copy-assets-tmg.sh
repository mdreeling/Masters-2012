
cp ../site/public/index.html trackmygearfor.me/www
cp ../site/public/js/*.js trackmygearfor.me/www/js
cp ../site/public/img/*.png trackmygearfor.me/www/img

cp ../site/public/css/*.css trackmygearfor.me/www/css
cp ../site/public/css/images/*.png trackmygearfor.me/www/css/images
cp ../site/public/css/ios/*.css trackmygearfor.me/www/css/ios
cp ../site/public/css/ios/images/*.png trackmygearfor.me/www/css/ios/images
cp ../site/public/css/ios/images/*.gif trackmygearfor.me/www/css/ios/images

cp ../site/public/css/ios/style.css trackmygearfor.me/www/css/style.css


