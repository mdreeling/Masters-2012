
cp ../site/public/index.html pgapi/www
cp ../site/public/js/*.js pgapi/www/js
cp ../site/public/img/*.png pgapi/www/img

cp ../site/public/css/*.css pgapi/www/css
cp ../site/public/css/images/*.png pgapi/www/css/images
cp ../site/public/css/ios/*.css pgapi/www/css/ios
cp ../site/public/css/ios/images/*.png pgapi/www/css/ios/images
cp ../site/public/css/ios/images/*.gif pgapi/www/css/ios/images

cp ../site/public/css/ios/style.css pgapi/www/css/style.css


