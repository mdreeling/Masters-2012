module.exports = {
    TrackMyGear: {
      dbName: "inventorylist",
      dbHost: "services.dreeling.com",
      dbPort: 27017
    }
  }