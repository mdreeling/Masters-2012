var initialscreen = "login"
var modelurl = "/api/rest/inventory"
var twitterauthurl = "/auth/twitter"
var sendmailurl = '/sendmail/tmg@dreeling.com/'
